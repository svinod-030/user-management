import React, {useState} from 'react';
import './App.css';
import { save } from './service/UserService';


const AddUser =  ({refreshData}) => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [status, setStatus] = useState('');

    const handleFirstNameChange = (event) => {
        event.preventDefault();
        setFirstName(event.target.value);
    }
    const handleLastNameChange = (event) => {
        event.preventDefault();
        setLastName(event.target.value);
    }
    const handleEmailChange = (event) => {
        event.preventDefault();
        setEmail(event.target.value);
    }
    const handleStatusChange = (event) => {
        event.preventDefault();
        setStatus(event.target.value);
    }
    const handleSubmit = async (event) => {
        event.preventDefault();
        await save({firstName, lastName, email, status})
        refreshData()
    }
    return (
        <form onSubmit={handleSubmit}>
            <input name={'firstName'} placeholder={'First Name'} onKeyUp={handleFirstNameChange}/>
            <input name={'lastName'} placeholder={'Last Name'} onKeyUp={handleLastNameChange}/>
            <input type={'email'} name={'email'} placeholder={'Email'} onKeyUp={handleEmailChange}/>
            <input name={'status'} placeholder={'Status'} onKeyUp={handleStatusChange}/>
            <input type="submit" value="Add User" />
        </form>
  );
}

export default AddUser;