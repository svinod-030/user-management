import React, {useEffect, useState} from 'react';
import './App.css';
import Table from 'rc-table';
import { deleteUser } from './service/UserService';

const Users =  ({data, refreshData}) => {

    const deleteUserFromDB = async (id) => {
        await deleteUser(id);
        refreshData();
    }

    useEffect(() => {
        refreshData();
    }, [])
    const columns = [
        {
            title: 'First Name',
            dataIndex: 'firstName',
            key: 'firstName',
            width: 100,
        },
        {
            title: 'Last Name',
            dataIndex: 'lastName',
            key: 'lastName',
            width: 100,
        },
        {
            title: 'Email',
            dataIndex: 'email',
            key: 'email',
            width: 100,
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            width: 100,
        },
        {
            title: 'Action',
            dataIndex: '',
            key: 'action',
            render: (value) => <div>
                <a href="#" onClick={() => deleteUserFromDB(value.id)}>Delete</a>
            </div>,
        },
    ]
    return (
        <div>
            <Table
                columns={columns}
                data={data}
            />
        </div>
  );
}

export default Users;