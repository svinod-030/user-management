import './App.css';
import Users from './Users';
import AddUser from "./AddUser";
import React, {useState} from "react";
import {getUsers} from "./service/UserService";

function App() {
    const [data, setData] = useState([]);

    const refreshData = () => {
        getUsers().then((data) => setData(data))
    }
  return (
    <div className="App">
      <header className="App-header">
        <h1>User Management</h1>
        <AddUser refreshData={refreshData}/>
        <Users data={data} refreshData={refreshData}/>
      </header>
    </div>
  );
}

export default App;
